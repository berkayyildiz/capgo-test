# Notes

- Don't place scroll to a far parent of scrollable content, always place scroll as a wrapper as parent of scrollable content
