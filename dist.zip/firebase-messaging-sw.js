try {
  importScripts("https://www.gstatic.com/firebasejs/8.2.4/firebase-app.js")
  importScripts("https://www.gstatic.com/firebasejs/8.2.4/firebase-messaging.js")
  firebase.initializeApp({
    apiKey: "AIzaSyAJ50Zv-sp95lY8x89Wa6RR2r4u2iIBJ8c",
    authDomain: "dfa-prod.firebaseapp.com",
    projectId: "dfa-prod",
    storageBucket: "dfa-prod.appspot.com",
    messagingSenderId: "316019551961",
    appId: "1:316019551961:web:20b16ec0802aea25fa58c8",
    measurementId: "G-NCKCWPPDBY",
  })
  const messaging = firebase.messaging()
} catch (e) {
  console.error("Error on firebase service worker init")
}
